echo "HttpTrickyServer 0"
java -jar HttpTrickyServer.jar 8080 &
echo "HttpTrickyServer 1"
java -jar HttpTrickyServer.jar 8081 &
echo "HttpTrickyServer 2"
java -jar HttpTrickyServer.jar 8082 &
echo "HttpTrickyServer 3"
java -jar HttpTrickyServer.jar 8083 &
